import 'package:flutter/material.dart';

abstract class AppColors {
  static const Color primary = Color(0xFF0F172A);
  static const Color accent = Color(0xFF2563EB);
  static const Color background = Color(0xFFF8FAFC);
  static const Color card = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF111827);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color border = Color(0xFFE5E7EB);
}
