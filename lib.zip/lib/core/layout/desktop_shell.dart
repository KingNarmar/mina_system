import 'package:flutter/material.dart';
import 'package:mina_system/core/theme/app_colors.dart';

class DesktopShell extends StatefulWidget {
  const DesktopShell({super.key});

  @override
  State<DesktopShell> createState() => _DesktopShellState();
}

class _DesktopShellState extends State<DesktopShell> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          Container(
            width: 260,
            color: AppColors.primary,
            child: const Center(
              child: Text(
                'M.I.N.A System',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
          const Expanded(child: Center(child: Text('Desktop Dashboard Shell'))),
        ],
      ),
    );
  }
}
