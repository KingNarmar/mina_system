-- =========================================================
-- 03_storage.sql
-- Mina System / M.I.N.A System
-- Supabase Storage Buckets + Storage RLS Policies
-- =========================================================

insert into storage.buckets (id, name, public)
values
  ('company-assets', 'company-assets', false),
  ('transaction-proofs', 'transaction-proofs', false),
  ('custody-documents', 'custody-documents', false)
on conflict (id) do update
set public = excluded.public;

drop policy if exists "Members can read company assets" on storage.objects;
create policy "Members can read company assets"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'company-assets'
  and private.is_company_member(private.company_id_from_storage_path(name))
);

drop policy if exists "Members can read transaction proofs" on storage.objects;
create policy "Members can read transaction proofs"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'transaction-proofs'
  and private.is_company_member(private.company_id_from_storage_path(name))
);

drop policy if exists "Members can read custody documents" on storage.objects;
create policy "Members can read custody documents"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'custody-documents'
  and private.is_company_member(private.company_id_from_storage_path(name))
);

drop policy if exists "Owners and admins can upload company assets" on storage.objects;
create policy "Owners and admins can upload company assets"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'company-assets'
  and private.has_company_role(
    private.company_id_from_storage_path(name),
    array['owner', 'admin']::public.company_member_role[]
  )
);

drop policy if exists "Owner admin warehouse can upload transaction proofs" on storage.objects;
create policy "Owner admin warehouse can upload transaction proofs"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'transaction-proofs'
  and private.has_company_role(
    private.company_id_from_storage_path(name),
    array['owner', 'admin', 'warehouse_user']::public.company_member_role[]
  )
);

drop policy if exists "Owner admin warehouse can upload custody documents" on storage.objects;
create policy "Owner admin warehouse can upload custody documents"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'custody-documents'
  and private.has_company_role(
    private.company_id_from_storage_path(name),
    array['owner', 'admin', 'warehouse_user']::public.company_member_role[]
  )
);

-- No update/delete policies for sensitive files in v1.
-- Signed PDFs and proof images should not be deleted after being linked.
