-- =========================================================
-- 01_schema.sql
-- Mina System / M.I.N.A System
-- Supabase SQL Schema
--
-- System Type:
-- Custody Tracking System - NOT Inventory Stock Management
--
-- Non-negotiable:
-- - No opening_stock
-- - No available_stock
-- - No stock_balance
-- - No custody balance stored in workers/tools
-- - Custody balance is calculated from transactions only
-- =========================================================

create extension if not exists pgcrypto;

-- =========================================================
-- ENUM TYPES
-- =========================================================

do $$
begin
  if not exists (select 1 from pg_type where typname = 'company_member_role') then
    create type public.company_member_role as enum ('owner', 'admin', 'warehouse_user', 'viewer');
  end if;

  if not exists (select 1 from pg_type where typname = 'member_status') then
    create type public.member_status as enum ('active', 'inactive', 'invited');
  end if;

  if not exists (select 1 from pg_type where typname = 'worker_status') then
    create type public.worker_status as enum ('active', 'inactive', 'left_company');
  end if;

  if not exists (select 1 from pg_type where typname = 'tool_status') then
    create type public.tool_status as enum ('active', 'inactive', 'discontinued');
  end if;

  if not exists (select 1 from pg_type where typname = 'transaction_kind') then
    create type public.transaction_kind as enum ('issue', 'return', 'lost', 'damaged');
  end if;

  if not exists (select 1 from pg_type where typname = 'approval_status') then
    create type public.approval_status as enum ('not_required', 'pending', 'approved', 'rejected');
  end if;

  if not exists (select 1 from pg_type where typname = 'report_status') then
    create type public.report_status as enum ('signed', 'voided');
  end if;

  if not exists (select 1 from pg_type where typname = 'document_report_type') then
    create type public.document_report_type as enum (
      'custody_acknowledgement',
      'loss_damage_report',
      'worker_custody_report',
      'tool_history_report',
      'transactions_report',
      'lost_damaged_report',
      'tool_summary_report'
    );
  end if;

  if not exists (select 1 from pg_type where typname = 'loss_damage_kind') then
    create type public.loss_damage_kind as enum ('lost', 'damaged');
  end if;
end $$;

-- =========================================================
-- UPDATED_AT TRIGGER FUNCTION
-- =========================================================

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- =========================================================
-- IDENTITY & COMPANY TABLES
-- =========================================================

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid not null unique references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null,
  phone text,
  avatar_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists set_profiles_updated_at on public.profiles;
create trigger set_profiles_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  trade_name text,
  legal_name text,
  trade_license_no text,
  tax_registration_no text,
  address_line_1 text,
  address_line_2 text,
  city text,
  country text,
  phone text,
  email text,
  website text,
  logo_path text,
  created_by_profile_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint companies_logo_path_not_local check (
    logo_path is null
    or (
      logo_path !~* '^(file:|[A-Z]:\\|/storage/|/Users/)'
      and logo_path like id::text || '/%'
    )
  )
);

drop trigger if exists set_companies_updated_at on public.companies;
create trigger set_companies_updated_at
before update on public.companies
for each row execute function public.set_updated_at();

create table if not exists public.company_members (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  role public.company_member_role not null default 'warehouse_user',
  status public.member_status not null default 'active',
  joined_at timestamptz,
  invited_by_profile_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint company_members_unique_member unique (company_id, profile_id)
);

drop trigger if exists set_company_members_updated_at on public.company_members;
create trigger set_company_members_updated_at
before update on public.company_members
for each row execute function public.set_updated_at();

-- =========================================================
-- COMPANY REPORT SETTINGS & DOCUMENT TEMPLATES
-- =========================================================

create table if not exists public.company_report_settings (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null unique references public.companies(id) on delete cascade,
  default_timezone text not null default 'Asia/Dubai',
  date_format text not null default 'dd-MMM-yyyy',
  time_format text not null default 'HH:mm',
  show_company_logo boolean not null default true,
  show_company_details boolean not null default true,
  show_document_control boolean not null default true,
  show_generated_by boolean not null default true,
  report_footer_text text default 'This document was generated by Mina System.',
  custody_responsibility_statement text default 'I acknowledge receiving the listed tools in good condition and accept responsibility for returning them or reporting any loss/damage according to company policy.',
  loss_damage_responsibility_statement text default 'I confirm that the listed lost/damaged tool has been reviewed and approved for clearance from the worker custody according to company policy.',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists set_company_report_settings_updated_at on public.company_report_settings;
create trigger set_company_report_settings_updated_at
before update on public.company_report_settings
for each row execute function public.set_updated_at();

create table if not exists public.company_document_templates (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  report_type public.document_report_type not null,
  document_title text not null,
  document_code text not null,
  issue_no text not null default '1',
  revision_no text not null default '0',
  effective_date date not null default current_date,
  prepared_by_title text,
  checked_by_title text,
  approved_by_title text,
  worker_signature_label text default 'Worker Signature',
  manager_signature_label text default 'Manager Signature',
  storekeeper_signature_label text default 'Store Keeper Signature',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint company_document_templates_company_id_id_unique unique (company_id, id),
  constraint company_document_templates_unique_code unique (company_id, report_type, document_code)
);

create unique index if not exists company_document_templates_one_active_per_type_idx
on public.company_document_templates (company_id, report_type)
where is_active = true;

drop trigger if exists set_company_document_templates_updated_at on public.company_document_templates;
create trigger set_company_document_templates_updated_at
before update on public.company_document_templates
for each row execute function public.set_updated_at();

-- =========================================================
-- LOOKUPS
-- =========================================================

create table if not exists public.departments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  code text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint departments_company_id_id_unique unique (company_id, id)
);

create unique index if not exists departments_unique_name_per_company_idx
on public.departments (company_id, lower(btrim(name)));

drop trigger if exists set_departments_updated_at on public.departments;
create trigger set_departments_updated_at
before update on public.departments
for each row execute function public.set_updated_at();

create table if not exists public.job_titles (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  department_id uuid not null,
  name text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint job_titles_company_id_id_unique unique (company_id, id),
  constraint job_titles_company_id_id_department_id_unique unique (company_id, id, department_id),
  constraint job_titles_department_fk
    foreign key (company_id, department_id)
    references public.departments (company_id, id)
    on delete restrict
);

create unique index if not exists job_titles_unique_name_per_department_idx
on public.job_titles (company_id, department_id, lower(btrim(name)));

drop trigger if exists set_job_titles_updated_at on public.job_titles;
create trigger set_job_titles_updated_at
before update on public.job_titles
for each row execute function public.set_updated_at();

create table if not exists public.tool_units (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  symbol text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint tool_units_company_id_id_unique unique (company_id, id)
);

create unique index if not exists tool_units_unique_name_per_company_idx
on public.tool_units (company_id, lower(btrim(name)));

drop trigger if exists set_tool_units_updated_at on public.tool_units;
create trigger set_tool_units_updated_at
before update on public.tool_units
for each row execute function public.set_updated_at();

create table if not exists public.tool_categories (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  code text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint tool_categories_company_id_id_unique unique (company_id, id)
);

create unique index if not exists tool_categories_unique_name_per_company_idx
on public.tool_categories (company_id, lower(btrim(name)));

drop trigger if exists set_tool_categories_updated_at on public.tool_categories;
create trigger set_tool_categories_updated_at
before update on public.tool_categories
for each row execute function public.set_updated_at();

-- =========================================================
-- WORKERS & TOOLS
-- =========================================================

create table if not exists public.workers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  worker_code text not null,
  hr_code text not null,
  full_name text not null,
  department_id uuid not null,
  job_title_id uuid not null,
  phone text,
  email text,
  status public.worker_status not null default 'active',
  notes text,
  created_by_profile_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint workers_company_id_id_unique unique (company_id, id),
  constraint workers_unique_worker_code unique (company_id, worker_code),
  constraint workers_unique_hr_code unique (company_id, hr_code),
  constraint workers_department_fk
    foreign key (company_id, department_id)
    references public.departments (company_id, id)
    on delete restrict,
  constraint workers_job_title_same_department_fk
    foreign key (company_id, job_title_id, department_id)
    references public.job_titles (company_id, id, department_id)
    on delete restrict
);

create index if not exists workers_company_id_idx on public.workers (company_id);
create index if not exists workers_department_id_idx on public.workers (department_id);
create index if not exists workers_job_title_id_idx on public.workers (job_title_id);
create index if not exists workers_full_name_search_idx on public.workers (company_id, lower(btrim(full_name)));

drop trigger if exists set_workers_updated_at on public.workers;
create trigger set_workers_updated_at
before update on public.workers
for each row execute function public.set_updated_at();

create table if not exists public.tools (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  tool_code text not null,
  tool_name text not null,
  unit_id uuid not null,
  category_id uuid not null,
  description text,
  status public.tool_status not null default 'active',
  created_by_profile_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint tools_company_id_id_unique unique (company_id, id),
  constraint tools_unique_tool_code unique (company_id, tool_code),
  constraint tools_unit_fk
    foreign key (company_id, unit_id)
    references public.tool_units (company_id, id)
    on delete restrict,
  constraint tools_category_fk
    foreign key (company_id, category_id)
    references public.tool_categories (company_id, id)
    on delete restrict
);

create unique index if not exists tools_unique_normalized_name_per_company_idx
on public.tools (company_id, lower(btrim(tool_name)));

create index if not exists tools_company_id_idx on public.tools (company_id);
create index if not exists tools_unit_id_idx on public.tools (unit_id);
create index if not exists tools_category_id_idx on public.tools (category_id);

drop trigger if exists set_tools_updated_at on public.tools;
create trigger set_tools_updated_at
before update on public.tools
for each row execute function public.set_updated_at();

-- =========================================================
-- TRANSACTIONS
-- =========================================================

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  transaction_code text not null,
  transaction_type public.transaction_kind not null,
  worker_id uuid not null,
  worker_hr_code_snapshot text not null,
  worker_name_snapshot text not null,
  worker_department_snapshot text not null,
  worker_job_title_snapshot text not null,
  tool_id uuid not null,
  tool_code_snapshot text not null,
  tool_name_snapshot text not null,
  tool_unit_snapshot text not null,
  tool_category_snapshot text not null,
  quantity numeric(12, 2) not null,
  proof_image_path text,
  note text,
  approval_required boolean not null default false,
  approval_status public.approval_status not null default 'not_required',
  created_by_profile_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint transactions_company_id_id_unique unique (company_id, id),
  constraint transactions_unique_code unique (company_id, transaction_code),
  constraint transactions_worker_fk
    foreign key (company_id, worker_id)
    references public.workers (company_id, id)
    on delete restrict,
  constraint transactions_tool_fk
    foreign key (company_id, tool_id)
    references public.tools (company_id, id)
    on delete restrict,
  constraint transactions_quantity_positive check (quantity > 0),
  constraint transactions_required_image_by_type check (
    transaction_type not in ('issue', 'damaged')
    or (proof_image_path is not null and btrim(proof_image_path) <> '')
  ),
  constraint transactions_lost_damaged_requires_note check (
    transaction_type not in ('lost', 'damaged')
    or (note is not null and btrim(note) <> '')
  ),
  constraint transactions_approval_logic check (
    (
      transaction_type in ('issue', 'return')
      and approval_required = false
      and approval_status = 'not_required'
    )
    or
    (
      transaction_type in ('lost', 'damaged')
      and approval_required = true
      and approval_status in ('pending', 'approved', 'rejected')
    )
  ),
  constraint transactions_proof_image_path_not_local check (
    proof_image_path is null
    or (
      proof_image_path !~* '^(file:|[A-Z]:\\|/storage/|/Users/)'
      and proof_image_path like company_id::text || '/%'
    )
  )
);

create index if not exists transactions_company_id_idx on public.transactions (company_id);
create index if not exists transactions_worker_id_idx on public.transactions (worker_id);
create index if not exists transactions_tool_id_idx on public.transactions (tool_id);
create index if not exists transactions_type_idx on public.transactions (company_id, transaction_type);
create index if not exists transactions_approval_status_idx on public.transactions (company_id, approval_status);
create index if not exists transactions_created_at_idx on public.transactions (company_id, created_at desc);

drop trigger if exists set_transactions_updated_at on public.transactions;
create trigger set_transactions_updated_at
before update on public.transactions
for each row execute function public.set_updated_at();

-- =========================================================
-- SIGNED CUSTODY ACKNOWLEDGEMENTS
-- =========================================================

create table if not exists public.custody_acknowledgements (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  worker_id uuid not null,
  acknowledgement_code text not null,
  version_no integer not null,
  generated_after_transaction_id uuid,
  document_template_id uuid,
  document_title_snapshot text not null,
  document_code_snapshot text not null,
  issue_no_snapshot text not null,
  revision_no_snapshot text not null,
  effective_date_snapshot date not null,
  worker_name_snapshot text not null,
  worker_hr_code_snapshot text not null,
  worker_department_snapshot text not null,
  worker_job_title_snapshot text not null,
  signed_pdf_path text not null,
  signed_at timestamptz not null,
  status public.report_status not null default 'signed',
  voided_at timestamptz,
  voided_by_profile_id uuid references public.profiles(id) on delete set null,
  void_reason text,
  created_by_profile_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint custody_acknowledgements_company_id_id_unique unique (company_id, id),
  constraint custody_acknowledgements_unique_code unique (company_id, acknowledgement_code),
  constraint custody_acknowledgements_unique_worker_version unique (company_id, worker_id, version_no),
  constraint custody_acknowledgements_worker_fk
    foreign key (company_id, worker_id)
    references public.workers (company_id, id)
    on delete restrict,
  constraint custody_acknowledgements_generated_after_transaction_fk
    foreign key (company_id, generated_after_transaction_id)
    references public.transactions (company_id, id)
    on delete restrict,
  constraint custody_acknowledgements_template_fk
    foreign key (company_id, document_template_id)
    references public.company_document_templates (company_id, id)
    on delete restrict,
  constraint custody_acknowledgements_signed_pdf_path_not_local check (
    signed_pdf_path !~* '^(file:|[A-Z]:\\|/storage/|/Users/)'
    and signed_pdf_path like company_id::text || '/%'
  ),
  constraint custody_acknowledgements_void_requires_details check (
    status <> 'voided'
    or (
      voided_at is not null
      and voided_by_profile_id is not null
      and void_reason is not null
      and btrim(void_reason) <> ''
    )
  )
);

create index if not exists custody_acknowledgements_company_id_idx
on public.custody_acknowledgements (company_id);

create index if not exists custody_acknowledgements_worker_signed_at_idx
on public.custody_acknowledgements (company_id, worker_id, signed_at desc);

drop trigger if exists set_custody_acknowledgements_updated_at on public.custody_acknowledgements;
create trigger set_custody_acknowledgements_updated_at
before update on public.custody_acknowledgements
for each row execute function public.set_updated_at();

create table if not exists public.custody_acknowledgement_items (
  id uuid primary key default gen_random_uuid(),
  acknowledgement_id uuid not null,
  company_id uuid not null,
  tool_id uuid not null,
  tool_code_snapshot text not null,
  tool_name_snapshot text not null,
  tool_unit_snapshot text not null,
  tool_category_snapshot text not null,
  open_quantity_snapshot numeric(12, 2) not null,
  last_issue_transaction_id uuid,
  last_proof_image_path_snapshot text,
  created_at timestamptz not null default now(),
  constraint custody_acknowledgement_items_quantity_positive check (open_quantity_snapshot > 0),
  constraint custody_acknowledgement_items_acknowledgement_fk
    foreign key (company_id, acknowledgement_id)
    references public.custody_acknowledgements (company_id, id)
    on delete cascade,
  constraint custody_acknowledgement_items_tool_fk
    foreign key (company_id, tool_id)
    references public.tools (company_id, id)
    on delete restrict,
  constraint custody_acknowledgement_items_last_issue_transaction_fk
    foreign key (company_id, last_issue_transaction_id)
    references public.transactions (company_id, id)
    on delete restrict,
  constraint custody_acknowledgement_items_last_proof_path_not_local check (
    last_proof_image_path_snapshot is null
    or (
      last_proof_image_path_snapshot !~* '^(file:|[A-Z]:\\|/storage/|/Users/)'
      and last_proof_image_path_snapshot like company_id::text || '/%'
    )
  )
);

create index if not exists custody_acknowledgement_items_acknowledgement_id_idx
on public.custody_acknowledgement_items (acknowledgement_id);

create index if not exists custody_acknowledgement_items_company_id_idx
on public.custody_acknowledgement_items (company_id);

-- =========================================================
-- LOSS / DAMAGE REPORTS
-- =========================================================

create table if not exists public.loss_damage_reports (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  transaction_id uuid not null,
  worker_id uuid not null,
  tool_id uuid not null,
  report_code text not null,
  report_type public.loss_damage_kind not null,
  document_template_id uuid,
  document_title_snapshot text not null,
  document_code_snapshot text not null,
  issue_no_snapshot text not null,
  revision_no_snapshot text not null,
  effective_date_snapshot date not null,
  worker_name_snapshot text not null,
  worker_hr_code_snapshot text not null,
  worker_department_snapshot text not null,
  worker_job_title_snapshot text not null,
  tool_code_snapshot text not null,
  tool_name_snapshot text not null,
  tool_unit_snapshot text not null,
  tool_category_snapshot text not null,
  quantity_snapshot numeric(12, 2) not null,
  proof_image_path_snapshot text,
  incident_note_snapshot text not null,
  manager_name_snapshot text not null,
  manager_job_title_snapshot text,
  manager_department_snapshot text,
  signed_pdf_path text not null,
  signed_at timestamptz not null,
  status public.report_status not null default 'signed',
  voided_at timestamptz,
  voided_by_profile_id uuid references public.profiles(id) on delete set null,
  void_reason text,
  created_by_profile_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint loss_damage_reports_company_id_id_unique unique (company_id, id),
  constraint loss_damage_reports_unique_code unique (company_id, report_code),
  constraint loss_damage_reports_quantity_positive check (quantity_snapshot > 0),
  constraint loss_damage_reports_transaction_fk
    foreign key (company_id, transaction_id)
    references public.transactions (company_id, id)
    on delete restrict,
  constraint loss_damage_reports_worker_fk
    foreign key (company_id, worker_id)
    references public.workers (company_id, id)
    on delete restrict,
  constraint loss_damage_reports_tool_fk
    foreign key (company_id, tool_id)
    references public.tools (company_id, id)
    on delete restrict,
  constraint loss_damage_reports_template_fk
    foreign key (company_id, document_template_id)
    references public.company_document_templates (company_id, id)
    on delete restrict,
  constraint loss_damage_reports_signed_pdf_path_not_local check (
    signed_pdf_path !~* '^(file:|[A-Z]:\\|/storage/|/Users/)'
    and signed_pdf_path like company_id::text || '/%'
  ),
  constraint loss_damage_reports_proof_path_not_local check (
    proof_image_path_snapshot is null
    or (
      proof_image_path_snapshot !~* '^(file:|[A-Z]:\\|/storage/|/Users/)'
      and proof_image_path_snapshot like company_id::text || '/%'
    )
  ),
  constraint loss_damage_reports_void_requires_details check (
    status <> 'voided'
    or (
      voided_at is not null
      and voided_by_profile_id is not null
      and void_reason is not null
      and btrim(void_reason) <> ''
    )
  )
);

create index if not exists loss_damage_reports_company_id_idx
on public.loss_damage_reports (company_id);

create index if not exists loss_damage_reports_worker_signed_at_idx
on public.loss_damage_reports (company_id, worker_id, signed_at desc);

create index if not exists loss_damage_reports_transaction_id_idx
on public.loss_damage_reports (transaction_id);

drop trigger if exists set_loss_damage_reports_updated_at on public.loss_damage_reports;
create trigger set_loss_damage_reports_updated_at
before update on public.loss_damage_reports
for each row execute function public.set_updated_at();

-- =========================================================
-- ENABLE RLS
-- Policies are created in 02_rls_policies.sql
-- =========================================================

alter table public.profiles enable row level security;
alter table public.companies enable row level security;
alter table public.company_members enable row level security;
alter table public.company_report_settings enable row level security;
alter table public.company_document_templates enable row level security;
alter table public.departments enable row level security;
alter table public.job_titles enable row level security;
alter table public.tool_units enable row level security;
alter table public.tool_categories enable row level security;
alter table public.workers enable row level security;
alter table public.tools enable row level security;
alter table public.transactions enable row level security;
alter table public.custody_acknowledgements enable row level security;
alter table public.custody_acknowledgement_items enable row level security;
alter table public.loss_damage_reports enable row level security;
