-- =========================================================
-- 04_rpc_planning.sql
-- Mina System / M.I.N.A System
-- RPC Functions Planning Notes
-- =========================================================

-- This file is intentionally a planning file, not a full implementation.
-- The following RPCs are recommended before production integration:

-- 1. create_company_with_defaults
--    - create company
--    - create owner company_members record
--    - create company_report_settings
--    - seed tool_units: Each / KG / MTR
--    - seed document templates

-- 2. get_worker_tool_balance
--    Balance formula:
--      issue    = + quantity
--      return   = - quantity
--      lost     = - quantity only if approval_status = approved
--      damaged  = - quantity only if approval_status = approved

-- 3. get_worker_open_custody
--    Returns current open custody list for a worker.

-- 4. create_custody_transaction
--    - validates role
--    - validates worker/tool company
--    - validates quantity
--    - validates proof_image_path for issue/damaged
--    - validates return/lost/damaged against open balance
--    - stores snapshots
--    - inserts transaction

-- 5. create_custody_acknowledgement
--    - validates signed_pdf_path
--    - stores document snapshot
--    - stores worker snapshot
--    - stores open custody items snapshot

-- 6. approve_loss_damage_transaction
--    - validates pending lost/damaged transaction
--    - validates signed_pdf_path
--    - inserts loss_damage_report
--    - updates transaction approval_status = approved
