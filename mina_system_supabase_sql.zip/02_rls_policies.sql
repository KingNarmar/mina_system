-- =========================================================
-- 02_rls_policies.sql
-- Mina System / M.I.N.A System
-- Row Level Security Policies
-- =========================================================

create schema if not exists private;

create or replace function private.current_profile_id()
returns uuid
language sql
security definer
set search_path = public, auth
as $$
  select p.id
  from public.profiles p
  where p.auth_user_id = auth.uid()
  limit 1;
$$;

create or replace function private.is_company_member(target_company_id uuid)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.company_members cm
    where cm.company_id = target_company_id
      and cm.profile_id = private.current_profile_id()
      and cm.status = 'active'
  );
$$;

create or replace function private.has_company_role(
  target_company_id uuid,
  allowed_roles public.company_member_role[]
)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.company_members cm
    where cm.company_id = target_company_id
      and cm.profile_id = private.current_profile_id()
      and cm.status = 'active'
      and cm.role = any(allowed_roles)
  );
$$;

create or replace function private.company_id_from_storage_path(object_name text)
returns uuid
language plpgsql
immutable
as $$
begin
  return split_part(object_name, '/', 1)::uuid;
exception
  when others then
    return null;
end;
$$;

-- PROFILES
drop policy if exists "Users can read their own profile" on public.profiles;
create policy "Users can read their own profile"
on public.profiles for select to authenticated
using (auth_user_id = (select auth.uid()));

drop policy if exists "Users can insert their own profile" on public.profiles;
create policy "Users can insert their own profile"
on public.profiles for insert to authenticated
with check (auth_user_id = (select auth.uid()));

drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile"
on public.profiles for update to authenticated
using (auth_user_id = (select auth.uid()))
with check (auth_user_id = (select auth.uid()));

-- COMPANIES
drop policy if exists "Members can read their companies" on public.companies;
create policy "Members can read their companies"
on public.companies for select to authenticated
using (private.is_company_member(id));

drop policy if exists "Authenticated users can create companies" on public.companies;
create policy "Authenticated users can create companies"
on public.companies for insert to authenticated
with check (created_by_profile_id = private.current_profile_id());

drop policy if exists "Owners and admins can update companies" on public.companies;
create policy "Owners and admins can update companies"
on public.companies for update to authenticated
using (private.has_company_role(id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(id, array['owner', 'admin']::public.company_member_role[]));

-- COMPANY MEMBERS
drop policy if exists "Members can read company members" on public.company_members;
create policy "Members can read company members"
on public.company_members for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owners can insert company members" on public.company_members;
create policy "Owners can insert company members"
on public.company_members for insert to authenticated
with check (private.has_company_role(company_id, array['owner']::public.company_member_role[]));

drop policy if exists "Owners can update company members" on public.company_members;
create policy "Owners can update company members"
on public.company_members for update to authenticated
using (private.has_company_role(company_id, array['owner']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner']::public.company_member_role[]));

-- SETTINGS + TEMPLATES
drop policy if exists "Members can read report settings" on public.company_report_settings;
create policy "Members can read report settings"
on public.company_report_settings for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owners and admins can insert report settings" on public.company_report_settings;
create policy "Owners and admins can insert report settings"
on public.company_report_settings for insert to authenticated
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Owners and admins can update report settings" on public.company_report_settings;
create policy "Owners and admins can update report settings"
on public.company_report_settings for update to authenticated
using (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Members can read document templates" on public.company_document_templates;
create policy "Members can read document templates"
on public.company_document_templates for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owners and admins can insert document templates" on public.company_document_templates;
create policy "Owners and admins can insert document templates"
on public.company_document_templates for insert to authenticated
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Owners and admins can update document templates" on public.company_document_templates;
create policy "Owners and admins can update document templates"
on public.company_document_templates for update to authenticated
using (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

-- LOOKUPS
drop policy if exists "Members can read departments" on public.departments;
create policy "Members can read departments"
on public.departments for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owners and admins can insert departments" on public.departments;
create policy "Owners and admins can insert departments"
on public.departments for insert to authenticated
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Owners and admins can update departments" on public.departments;
create policy "Owners and admins can update departments"
on public.departments for update to authenticated
using (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Members can read job titles" on public.job_titles;
create policy "Members can read job titles"
on public.job_titles for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owners and admins can insert job titles" on public.job_titles;
create policy "Owners and admins can insert job titles"
on public.job_titles for insert to authenticated
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Owners and admins can update job titles" on public.job_titles;
create policy "Owners and admins can update job titles"
on public.job_titles for update to authenticated
using (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Members can read tool units" on public.tool_units;
create policy "Members can read tool units"
on public.tool_units for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owners and admins can insert tool units" on public.tool_units;
create policy "Owners and admins can insert tool units"
on public.tool_units for insert to authenticated
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Owners and admins can update tool units" on public.tool_units;
create policy "Owners and admins can update tool units"
on public.tool_units for update to authenticated
using (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Members can read tool categories" on public.tool_categories;
create policy "Members can read tool categories"
on public.tool_categories for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owners and admins can insert tool categories" on public.tool_categories;
create policy "Owners and admins can insert tool categories"
on public.tool_categories for insert to authenticated
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Owners and admins can update tool categories" on public.tool_categories;
create policy "Owners and admins can update tool categories"
on public.tool_categories for update to authenticated
using (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

-- WORKERS + TOOLS
drop policy if exists "Members can read workers" on public.workers;
create policy "Members can read workers"
on public.workers for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owners and admins can insert workers" on public.workers;
create policy "Owners and admins can insert workers"
on public.workers for insert to authenticated
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Owners and admins can update workers" on public.workers;
create policy "Owners and admins can update workers"
on public.workers for update to authenticated
using (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Members can read tools" on public.tools;
create policy "Members can read tools"
on public.tools for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owners and admins can insert tools" on public.tools;
create policy "Owners and admins can insert tools"
on public.tools for insert to authenticated
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Owners and admins can update tools" on public.tools;
create policy "Owners and admins can update tools"
on public.tools for update to authenticated
using (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

-- TRANSACTIONS
drop policy if exists "Members can read transactions" on public.transactions;
create policy "Members can read transactions"
on public.transactions for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owner admin warehouse can insert transactions" on public.transactions;
create policy "Owner admin warehouse can insert transactions"
on public.transactions for insert to authenticated
with check (
  private.has_company_role(company_id, array['owner', 'admin', 'warehouse_user']::public.company_member_role[])
);

drop policy if exists "Owner admin warehouse can update pending transactions" on public.transactions;
create policy "Owner admin warehouse can update pending transactions"
on public.transactions for update to authenticated
using (
  private.has_company_role(company_id, array['owner', 'admin', 'warehouse_user']::public.company_member_role[])
  and approval_status in ('not_required', 'pending')
)
with check (
  private.has_company_role(company_id, array['owner', 'admin', 'warehouse_user']::public.company_member_role[])
);

-- CUSTODY ACKNOWLEDGEMENTS
drop policy if exists "Members can read custody acknowledgements" on public.custody_acknowledgements;
create policy "Members can read custody acknowledgements"
on public.custody_acknowledgements for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owner admin warehouse can insert custody acknowledgements" on public.custody_acknowledgements;
create policy "Owner admin warehouse can insert custody acknowledgements"
on public.custody_acknowledgements for insert to authenticated
with check (
  private.has_company_role(company_id, array['owner', 'admin', 'warehouse_user']::public.company_member_role[])
);

drop policy if exists "Owners and admins can void custody acknowledgements" on public.custody_acknowledgements;
create policy "Owners and admins can void custody acknowledgements"
on public.custody_acknowledgements for update to authenticated
using (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));

drop policy if exists "Members can read custody acknowledgement items" on public.custody_acknowledgement_items;
create policy "Members can read custody acknowledgement items"
on public.custody_acknowledgement_items for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owner admin warehouse can insert custody acknowledgement items" on public.custody_acknowledgement_items;
create policy "Owner admin warehouse can insert custody acknowledgement items"
on public.custody_acknowledgement_items for insert to authenticated
with check (
  private.has_company_role(company_id, array['owner', 'admin', 'warehouse_user']::public.company_member_role[])
);

-- LOSS DAMAGE REPORTS
drop policy if exists "Members can read loss damage reports" on public.loss_damage_reports;
create policy "Members can read loss damage reports"
on public.loss_damage_reports for select to authenticated
using (private.is_company_member(company_id));

drop policy if exists "Owner admin warehouse can insert loss damage reports" on public.loss_damage_reports;
create policy "Owner admin warehouse can insert loss damage reports"
on public.loss_damage_reports for insert to authenticated
with check (
  private.has_company_role(company_id, array['owner', 'admin', 'warehouse_user']::public.company_member_role[])
);

drop policy if exists "Owners and admins can void loss damage reports" on public.loss_damage_reports;
create policy "Owners and admins can void loss damage reports"
on public.loss_damage_reports for update to authenticated
using (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]))
with check (private.has_company_role(company_id, array['owner', 'admin']::public.company_member_role[]));
