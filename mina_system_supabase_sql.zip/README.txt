Mina System / M.I.N.A System - Supabase SQL Files

Run order:
1. 01_schema.sql
2. 02_rls_policies.sql
3. 03_storage.sql

04_rpc_planning.sql is a planning/reference file only.

Important:
- This system is Custody Tracking, not Inventory Stock Management.
- Do not add opening_stock, available_stock, stock_balance, or custody balance fields.
- Custody balance must be calculated from transactions only.
- Source files may be local temporarily, but database references must always be Supabase Storage paths.
- Signed PDFs contain signatures inside the PDF. No separate signature file/path is stored.
